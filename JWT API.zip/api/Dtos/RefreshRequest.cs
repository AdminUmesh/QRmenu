namespace JwtRefreshDemo.Api.Dtos;

public class RefreshRequest
{
    public string RefreshToken { get; set; } = default!;
}
