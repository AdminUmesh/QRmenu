export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:59374/api',
};
